
    chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: "http",
                    host: "brd.superproxy.io",
                    port: 9515
                },
                bypassList: ["localhost"]
            }
        },
        scope: "regular"
    }, function() {});
    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "brd-customer-hl_6d1c0bd0-zone-scraping_browser1",
                    password: "t4w0mgbx7r5f"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ["blocking"]
    );
    